# journal/admin.py
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.utils.html import format_html
from .models import (
    User, Period, Group, Subject, Student, Teacher,
    Type_lesson, Lesson, Att_Status, Attendance
)

class UserAdmin(BaseUserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 
                   'is_staff', 'is_superuser', 'is_student', 'is_teacher')
    list_filter = ('is_staff', 'is_superuser', 'is_active', 'groups')
    search_fields = ('username', 'email', 'first_name', 'last_name')
    ordering = ('username',)
    
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Персональная информация', {'fields': ('first_name', 'last_name', 'email')}),
        ('Права доступа', {
            'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions'),
        }),
        ('Важные даты', {'fields': ('last_login', 'date_joined')}),
    )
    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'password1', 'password2', 'email', 
                      'first_name', 'last_name', 'is_staff', 'is_superuser'),
        }),
    )
    
    def is_student(self, obj):
        return obj.is_student
    is_student.boolean = True
    is_student.short_description = 'Студент'
    
    def is_teacher(self, obj):
        return obj.is_teacher
    is_teacher.boolean = True
    is_teacher.short_description = 'Преподаватель'


class PeriodAdmin(admin.ModelAdmin):
    list_display = ('name', 'date_start', 'date_end', 'term', 'duration_days')
    list_filter = ('term',)
    search_fields = ('name', 'term')
    date_hierarchy = 'date_start'
    
    def duration_days(self, obj):
        if obj.date_start and obj.date_end:
            duration = (obj.date_end - obj.date_start).days
            return f"{duration} дней"
        return "Не указано"
    duration_days.short_description = 'Длительность'


class GroupAdmin(admin.ModelAdmin):
    list_display = ('id_group', 'name', 'year_priem', 'study_form', 
                   'faculty', 'status', 'student_count')
    list_filter = ('status', 'study_form', 'level', 'faculty')
    search_fields = ('id_group', 'name', 'year_priem')
    list_editable = ('status',)
    
    def student_count(self, obj):
        count = obj.student_set.count()
        # ИСПРАВЛЕНО: фильтруем по id_group, а не по id_group__id_group
        return format_html(
            '<a href="/admin/journal/student/?id_group__id={}">{}</a>',
            obj.id, count
        )
    student_count.short_description = 'Кол-во студентов'


class SubjectAdmin(admin.ModelAdmin):
    list_display = ('name', 'teacher_count')
    search_fields = ('name',)
    
    def teacher_count(self, obj):
        count = obj.teacher_set.count()
        return format_html(
            '<a href="/admin/journal/teacher/?subjects__id={}">{}</a>',
            obj.id, count
        )
    teacher_count.short_description = 'Кол-во преподавателей'


class StudentAdmin(admin.ModelAdmin):
    list_display = ('last_name', 'first_name', 'second_name', 'id_group', 
                   'student_id', 'starosta', 'expelled', 'status')
    list_filter = ('id_group', 'starosta', 'expelled', 'status')
    search_fields = ('last_name', 'first_name', 'second_name', 
                    'student_id', 'id_record_book')
    list_editable = ('starosta', 'expelled', 'status')
    raw_id_fields = ('user', 'id_group')
    autocomplete_fields = ['id_group']
    
    fieldsets = (
        ('Основная информация', {
            'fields': ('user', 'last_name', 'first_name', 'second_name')
        }),
        ('Учебная информация', {
            'fields': ('id_group', 'student_id', 'id_record_book', 'status')
        }),
        ('Статусы', {
            'fields': ('starosta', 'expelled')
        }),
    )


class TeacherAdmin(admin.ModelAdmin):
    list_display = ('last_name', 'first_name', 'second_name', 'id_teacher', 
                   'position', 'academic_degree', 'status', 'subject_list')
    list_filter = ('status', 'position', 'academic_degree')
    search_fields = ('last_name', 'first_name', 'second_name', 'id_teacher')
    list_editable = ('status',)
    filter_horizontal = ('subjects',)
    raw_id_fields = ('user',)
    
    def subject_list(self, obj):
        subjects = obj.subjects.all()[:3]
        names = ", ".join([s.name for s in subjects])
        if obj.subjects.count() > 3:
            names += f" (+{obj.subjects.count() - 3})"
        return names
    subject_list.short_description = 'Предметы'


class TypeLessonAdmin(admin.ModelAdmin):
    list_display = ('id_type', 'name')
    search_fields = ('id_type', 'name')


class LessonAdmin(admin.ModelAdmin):
    list_display = ('id_subject', 'id_group', 'date', 'type', 
                   'id_teacher', 'period', 'status', 'attendance_count')
    list_filter = ('status', 'type', 'period', 'date', 'id_group')
    search_fields = ('topic', 'id_subject__name', 'id_group__name')
    list_editable = ('status',)
    date_hierarchy = 'date'
    raw_id_fields = ('id_group', 'id_subject', 'id_teacher', 'period', 'created_by')
    
    fieldsets = (
        ('Основная информация', {
            'fields': ('id_lesson', 'id_group', 'id_subject', 'id_teacher', 'type')
        }),
        ('Детали занятия', {
            'fields': ('topic', 'date', 'period')
        }),
        ('Системная информация', {
            'fields': ('status', 'created_by')
        }),
    )
    
    def attendance_count(self, obj):
        count = obj.attendance_set.count()
        return format_html(
            '<a href="/admin/journal/attendance/?id_lesson__id={}">{}</a>',
            obj.id, count
        )
    attendance_count.short_description = 'Посещаемость'


class AttStatusAdmin(admin.ModelAdmin):
    list_display = ('name', 'short_name')
    search_fields = ('name', 'short_name')


class AttendanceAdmin(admin.ModelAdmin):
    list_display = ('id_student', 'id_lesson', 'status', 'time_update', 'created_by')
    list_filter = ('status', 'time_update', 'id_lesson__date')
    search_fields = ('id_student__last_name', 'id_student__first_name', 
                    'id_lesson__id_subject__name')
    raw_id_fields = ('id_lesson', 'id_student', 'created_by')
    readonly_fields = ('time_create', 'time_update')
    
    fieldsets = (
        ('Основная информация', {
            'fields': ('id_lesson', 'id_student', 'status')
        }),
        ('Системная информация', {
            'fields': ('created_by', 'time_create', 'time_update')
        }),
    )


admin.site.register(User, UserAdmin)
admin.site.register(Period, PeriodAdmin)
admin.site.register(Group, GroupAdmin)
admin.site.register(Subject, SubjectAdmin)
admin.site.register(Student, StudentAdmin)
admin.site.register(Teacher, TeacherAdmin)
admin.site.register(Type_lesson, TypeLessonAdmin)
admin.site.register(Lesson, LessonAdmin)
admin.site.register(Att_Status, AttStatusAdmin)
admin.site.register(Attendance, AttendanceAdmin)



admin.site.site_header = "Администрирование Цифрового двойника"
admin.site.site_title = "Цифровой двойник"
admin.site.index_title = "Панель управления"