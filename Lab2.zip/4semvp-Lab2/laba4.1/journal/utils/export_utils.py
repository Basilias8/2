import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from django.http import HttpResponse
from io import BytesIO
import datetime

def export_students_to_excel(group):
    """
    Экспорт списка студентов группы в Excel формат
    
    Args:
        group: объект Group
    """
    # Получаем студентов группы, не отчисленных, сортируем по фамилии
    students = group.student_set.filter(expelled=False).order_by('last_name', 'first_name')
    
    # Создаем новую книгу Excel
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Студенты"
    
    # Настраиваем стили
    header_font = Font(bold=True, size=12, color="FFFFFF")
    header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
    header_alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    
    cell_font = Font(size=11)
    cell_alignment = Alignment(horizontal="left", vertical="center")
    center_alignment = Alignment(horizontal="center", vertical="center")
    
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # Заголовок документа
    ws.merge_cells('A1:G1')
    title_cell = ws['A1']
    title_cell.value = f"Список студентов группы {group.name}"
    title_cell.font = Font(bold=True, size=14)
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    
    # Информация о группе
    ws.merge_cells('A2:G2')
    info_cell = ws['A2']
    info_cell.value = f"Дата формирования: {datetime.datetime.now().strftime('%d.%m.%Y %H:%M')}"
    info_cell.font = Font(italic=True, size=10)
    info_cell.alignment = Alignment(horizontal="center", vertical="center")
    
    # Заголовки столбцов (начинаем с 4 строки)
    headers = [
        ('№', 8),
        ('Фамилия', 20),
        ('Имя', 15),
        ('Отчество', 20),
        ('Номер зачетной книжки', 25),
        ('Статус', 15),
        ('Староста', 10)
    ]
    
    for col_idx, (header, width) in enumerate(headers, 1):
        cell = ws.cell(row=4, column=col_idx, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_alignment
        cell.border = thin_border
        ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = width
    
    # Заполняем данными о студентах
    for row_idx, student in enumerate(students, 5):  # Начинаем с 5 строки
        # Номер по порядку
        ws.cell(row=row_idx, column=1, value=row_idx - 4)
        ws.cell(row=row_idx, column=1).alignment = center_alignment
        
        # Фамилия
        ws.cell(row=row_idx, column=2, value=student.last_name)
        
        # Имя
        ws.cell(row=row_idx, column=3, value=student.first_name)
        
        # Отчество
        ws.cell(row=row_idx, column=4, value=student.second_name or '')
        
        # Номер зачетной книжки
        ws.cell(row=row_idx, column=5, value=student.id_record_book or '')
        
        # Статус
        ws.cell(row=row_idx, column=6, value=student.status or '')
        
        # Староста
        ws.cell(row=row_idx, column=7, value='✓' if student.starosta else '')
        ws.cell(row=row_idx, column=7).alignment = center_alignment
        
        # Применяем стили ко всем ячейкам строки
        for col in range(1, 8):
            cell = ws.cell(row=row_idx, column=col)
            cell.font = cell_font
            cell.alignment = cell_alignment if col not in [1, 7] else center_alignment
            cell.border = thin_border
    
    # Добавляем итоговую строку
    total_row = len(students) + 5
    ws.merge_cells(f'A{total_row}:D{total_row}')
    total_cell = ws.cell(row=total_row, column=1, value=f"Всего студентов: {len(students)}")
    total_cell.font = Font(bold=True)
    total_cell.alignment = Alignment(horizontal="right", vertical="center")
    
    # ИСПРАВЛЕННЫЙ БЛОК: Автоподбор ширины столбцов
    # Пропускаем обработку объединенных ячеек
    for col in range(1, 8):  # У нас 7 столбцов (A-G)
        max_length = 0
        column_letter = openpyxl.utils.get_column_letter(col)
        
        # Пропускаем строки с объединенными ячейками (1-4)
        for row in range(5, total_row + 1):  # Начинаем с 5 строки (данные студентов)
            cell = ws.cell(row=row, column=col)
            if cell.value:
                try:
                    cell_length = len(str(cell.value))
                    if cell_length > max_length:
                        max_length = cell_length
                except:
                    pass
        
        if max_length > 0:
            adjusted_width = min(max_length + 2, 50)
            # Проверяем, не меньше ли текущая ширина
            current_width = ws.column_dimensions[column_letter].width
            if current_width is None or adjusted_width > current_width:
                ws.column_dimensions[column_letter].width = adjusted_width
    
    # Сохраняем в буфер
    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    
    # Создаем HTTP ответ с файлом Excel
    response = HttpResponse(
        buffer.read(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    
    # Формируем имя файла (без запрещенных символов)
    filename = f"Студенты_{group.name}_{datetime.date.today()}.xlsx"
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    
    return response