# journal/forms.py
from django import forms
from .models import Subject, Group, Teacher, Attendance, Att_Status
from django.db.models import Q


class GroupFilterForm(forms.Form):
    """Форма фильтрации для списка групп"""
    name = forms.CharField(
        required=False,
        label="Название группы",
        widget=forms.TextInput(attrs={"class": "form-control", "placeholder": "Введите название"})
    )
    status = forms.ChoiceField(
        required=False,
        label="Статус группы",
        choices=[
            ('', 'все'),
            ('active', 'Активные'),
            ('inactive', 'Неактивные'),
        ],
        widget=forms.Select(attrs={"class": "form-control"})
    )


class LessonFilterForm(forms.Form):
    date = forms.DateField(
        required=False, 
        label="Дата занятия", 
        widget=forms.DateInput(attrs={"type": "date", "class": "form-control"})
    )
    subject = forms.ModelChoiceField(
        required=False, 
        label="Предмет", 
        queryset=Subject.objects.all(), 
        widget=forms.Select(attrs={"class": "form-control"})
    )
    group = forms.ModelChoiceField(
        required=False, 
        label="Группа", 
        queryset=Group.objects.all().order_by('name'),  # ВСЕ группы без фильтра по статусу
        widget=forms.Select(attrs={"class": "form-control"})
    )
    
    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)


class StudentFilterForm(forms.Form):
    last_name = forms.CharField(
        required=False, 
        label="Фамилия студента", 
        widget=forms.TextInput(attrs={"class": "form-control"})
    )
    status = forms.ChoiceField(
        required=False,
        label="Статус студента",
        choices=[
            ('', 'любой'),
            ('active', 'Активный'),
            ('expelled', 'Отчислен'),
        ],
        widget=forms.Select(attrs={"class": "form-control"})
    )
    starosta = forms.ChoiceField(
        required=False,
        label="Староста",
        choices=[
            ('', 'любой'),
            ('yes', 'Да'),
            ('no', 'Нет'),
        ],
        widget=forms.Select(attrs={"class": "form-control"})
    )


class AttendanceListFilterForm(forms.Form):
    # Получаем статусы из базы данных
    def get_status_choices():
        statuses = Att_Status.objects.all().values_list('id', 'name')
        choices = [('', 'любой')]
        choices.extend([(str(status[0]), status[1]) for status in statuses])
        return choices
    
    status = forms.ChoiceField(
        required=False, 
        label="Статус посещения",
        choices=get_status_choices,
        widget=forms.Select(attrs={"class": "form-control"})
    )
    last_name = forms.CharField(
        required=False, 
        label="Фамилия студента",
        widget=forms.TextInput(attrs={"class": "form-control"})
    )


# journal/forms.py (обновите только класс StudentAttendanceFilterForm)
from django import forms
from .models import Subject, Att_Status

class StudentAttendanceFilterForm(forms.Form):
    """Простая форма фильтрации посещаемости студента"""
    date_start = forms.DateField(
        required=False,
        label="Дата с",
        widget=forms.DateInput(attrs={
            "type": "date", 
            "class": "form-control",
            "placeholder": "Выберите дату"
        })
    )
    date_end = forms.DateField(
        required=False,
        label="Дата по",
        widget=forms.DateInput(attrs={
            "type": "date", 
            "class": "form-control",
            "placeholder": "Выберите дату"
        })
    )
    subject = forms.ModelChoiceField(
        required=False,
        label="Предмет",
        queryset=Subject.objects.none(),  # Будет заполнено динамически
        empty_label="Все предметы",
        widget=forms.Select(attrs={"class": "form-control"})
    )
    
    def __init__(self, *args, **kwargs):
        student = kwargs.pop('student', None)
        super().__init__(*args, **kwargs)
        
        if student and student.id_group:
            # Получаем предметы, которые есть у группы студента
            from .models import Lesson
            group_subjects = Lesson.objects.filter(
                id_group=student.id_group
            ).values_list('id_subject', flat=True).distinct()
            
            self.fields['subject'].queryset = Subject.objects.filter(
                id__in=group_subjects
            ).order_by('name')