from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView, TemplateView
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth import logout
from django.views.decorators.http import require_http_methods
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden, JsonResponse
from django.views import View
import json

from .models import Group, Student, Lesson, Attendance, Subject, Teacher, Att_Status
from .mixins import TeacherRequiredMixin, StudentRequiredMixin
from .forms import GroupFilterForm, LessonFilterForm, StudentFilterForm, AttendanceListFilterForm, StudentAttendanceFilterForm
from .utils.export_utils import export_students_to_excel

@require_http_methods(["GET", "POST"])
def custom_logout(request):
    logout(request)
    return redirect('home')

def home(request):
    """Главная страница"""
    context = {
        'title': 'Главная страница - Цифровой двойник'
    }
    return render(request, 'home.html', context)


# ================== ПРЕДСТАВЛЕНИЯ ПРЕПОДАВАТЕЛЯ ==================

class GroupListView(LoginRequiredMixin, TeacherRequiredMixin, ListView):
    """Список групп с фильтрацией"""
    model = Group
    template_name = "teacher/groups.html"
    context_object_name = "groups"
    paginate_by = 10
    
    def get_queryset(self):
        # Базовый QuerySet: все группы
        queryset = Group.objects.all()
        
        # Инициализируем форму фильтрации данными из GET-запроса
        self.filter_form = GroupFilterForm(self.request.GET)
        
        if self.filter_form.is_valid():
            # Получаем очищенные данные из формы
            cd = self.filter_form.cleaned_data
            
            # Фильтруем по названию группы
            if cd.get('name'):
                queryset = queryset.filter(name__icontains=cd['name'])
            
            # Фильтруем по статусу группы
            if cd.get('status'):
                if cd['status'] == 'active':
                    queryset = queryset.filter(status=True)
                elif cd['status'] == 'inactive':
                    queryset = queryset.filter(status=False)
        
        # Сортируем результаты
        queryset = queryset.order_by("name")
        
        return queryset
    
    def get_context_data(self, **kwargs):
        """Добавляем форму фильтрации и параметры фильтра в контекст шаблона."""
        context = super().get_context_data(**kwargs)
        context["title"] = "Список учебных групп"
        
        # Передаем форму в шаблон для отображения
        context['filter_form'] = self.filter_form
        
        # Сохраняем параметры фильтрации (кроме номера страницы) для использования в пагинации
        query_params = self.request.GET.copy()
        if 'page' in query_params:
            query_params.pop('page')
        context['filter_params'] = query_params.urlencode()
        
        # Добавляем количество отфильтрованных групп
        context["groups_count"] = self.get_queryset().count()
        
        return context


class StudentListView(LoginRequiredMixin, TeacherRequiredMixin, ListView):
    """Список студентов группы с фильтрацией"""
    model = Student
    template_name = "teacher/group_students.html"
    context_object_name = "students"
    paginate_by = 10
    
    def get_queryset(self):
        # Базовый QuerySet: все студенты конкретной группы
        group_id = self.kwargs.get("group_id")
        self.group = get_object_or_404(Group, pk=group_id)
        
        queryset = Student.objects.filter(id_group=self.group).select_related("user")
        
        # Инициализируем форму фильтрации данными из GET-запроса
        self.filter_form = StudentFilterForm(self.request.GET)
        
        if self.filter_form.is_valid():
            # Получаем очищенные данные из формы
            cd = self.filter_form.cleaned_data
            
            # Фильтруем по фамилии
            if cd.get('last_name'):
                queryset = queryset.filter(last_name__icontains=cd['last_name'])
            
            # Фильтруем по статусу студента
            if cd.get('status'):
                if cd['status'] == 'active':
                    queryset = queryset.filter(expelled=False)
                elif cd['status'] == 'expelled':
                    queryset = queryset.filter(expelled=True)
            
            # Фильтруем по статусу старосты
            if cd.get('starosta'):
                if cd['starosta'] == 'yes':
                    queryset = queryset.filter(starosta=True)
                elif cd['starosta'] == 'no':
                    queryset = queryset.filter(starosta=False)
        
        # Сортируем результаты
        queryset = queryset.order_by("last_name", "first_name", "second_name")
        
        return queryset
    
    def get_context_data(self, **kwargs):
        """Добавляем форму фильтрации и параметры фильтра в контекст шаблона."""
        context = super().get_context_data(**kwargs)
        context["group"] = self.group
        context["title"] = f"Студенты группы {self.group.name}"
        
        # Передаем форму в шаблон для отображения
        context['filter_form'] = self.filter_form
        
        # Сохраняем параметры фильтрации (кроме номера страницы) для использования в пагинации
        query_params = self.request.GET.copy()
        if 'page' in query_params:
            query_params.pop('page')
        context['filter_params'] = query_params.urlencode()
        
        # Добавляем количество отфильтрованных студентов
        context["students_count"] = self.get_queryset().count()
        
        return context


class TeacherLessonListView(LoginRequiredMixin, TeacherRequiredMixin, ListView):
    """Список занятий преподавателя с фильтрацией"""
    model = Lesson
    template_name = 'teacher/lessons.html'
    context_object_name = 'lessons'
    paginate_by = 10
    
    def get_queryset(self):
        # Базовый QuerySet: все занятия текущего преподавателя
        teacher = self.request.user.teacher
        queryset = Lesson.objects.filter(id_teacher=teacher)
        
        # Инициализируем форму фильтрации данными из GET-запроса
        self.filter_form = LessonFilterForm(self.request.GET, user=self.request.user)
        
        if self.filter_form.is_valid():
            # Получаем очищенные данные из формы
            cd = self.filter_form.cleaned_data
            
            # Фильтруем по дате, если указана
            if cd.get('date'):
                queryset = queryset.filter(date=cd['date'])
            
            # Фильтруем по выбранному предмету, если указан
            if cd.get('subject'):
                queryset = queryset.filter(id_subject=cd['subject'])
            
            # Фильтруем по группе, если указана
            if cd.get('group'):
                queryset = queryset.filter(id_group=cd['group'])
        
        # Оптимизируем запросы
        queryset = queryset.select_related(
            "id_subject",
            "id_teacher",
            "id_group",
            "type",
            "period"
        ).order_by("-date")
        
        return queryset
    
    def get_context_data(self, **kwargs):
        """Добавляем форму фильтрации и параметры фильтра в контекст шаблона."""
        context = super().get_context_data(**kwargs)
        context["title"] = "Мои занятия"
        
        # Передаем форму в шаблон для отображения
        context['filter_form'] = self.filter_form
        
        # Сохраняем параметры фильтрации (кроме номера страницы) для использования в пагинации
        query_params = self.request.GET.copy()
        if 'page' in query_params:
            query_params.pop('page')
        context['filter_params'] = query_params.urlencode()
        
        # Добавляем количество отфильтрованных занятий
        context["lessons_count"] = self.get_queryset().count()
        
        return context


class GroupLessonListView(LoginRequiredMixin, TeacherRequiredMixin, ListView):
    """Список занятий конкретной группы"""
    model = Lesson
    template_name = 'teacher/group_lessons.html'
    context_object_name = 'lessons'
    paginate_by = 10
    
    def get_queryset(self):
        # Базовый QuerySet: все занятия конкретной группы
        group_id = self.kwargs.get("group_id")
        self.group = get_object_or_404(Group, pk=group_id)
        
        queryset = Lesson.objects.filter(id_group=self.group)
        
        # Инициализируем форму фильтрации данными из GET-запроса
        self.filter_form = LessonFilterForm(self.request.GET, user=self.request.user)
        
        if self.filter_form.is_valid():
            # Получаем очищенные данные из формы
            cd = self.filter_form.cleaned_data
            
            # Фильтруем по дате, если указана
            if cd.get('date'):
                queryset = queryset.filter(date=cd['date'])
            
            # Фильтруем по выбранному предмету, если указан
            if cd.get('subject'):
                queryset = queryset.filter(id_subject=cd['subject'])
            
            # Игнорируем фильтр по группе, так как уже фильтруем по конкретной группе
        
        # Оптимизируем запросы
        queryset = queryset.select_related(
            "id_subject",
            "id_teacher",
            "id_group",
            "type",
            "period"
        ).order_by("-date")
        
        return queryset
    
    def get_context_data(self, **kwargs):
        """Добавляем форму фильтрации и параметры фильтра в контекст шаблона."""
        context = super().get_context_data(**kwargs)
        context["group"] = self.group
        context["title"] = f"Занятия группы {self.group.name}"
        
        # Передаем форму в шаблон для отображения
        context['filter_form'] = self.filter_form
        
        # Сохраняем параметры фильтрации (кроме номера страницы) для использования в пагинации
        query_params = self.request.GET.copy()
        if 'page' in query_params:
            query_params.pop('page')
        context['filter_params'] = query_params.urlencode()
        
        # Добавляем количество отфильтрованных занятий
        context["lessons_count"] = self.get_queryset().count()
        
        return context


class AttendanceListView(LoginRequiredMixin, TeacherRequiredMixin, View):
    """Представление для списка посещаемости конкретного занятия с AJAX."""
    template_name = 'teacher/lesson_attendance.html'
    
    def get(self, request, *args, **kwargs):
        """Обработка GET запроса - отображение страницы"""
        lesson_id = self.kwargs.get("lesson_id")
        lesson = get_object_or_404(Lesson, pk=lesson_id)
        
        # Инициализируем форму фильтрации
        filter_form = AttendanceListFilterForm(request.GET)
        
        # Получаем отфильтрованные посещения
        attendances = self._get_filtered_attendances(lesson, filter_form)
        
        # Пагинация
        from django.core.paginator import Paginator
        paginator = Paginator(attendances, 10)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        
        # Сохраняем параметры фильтрации
        query_params = request.GET.copy()
        if 'page' in query_params:
            query_params.pop('page')
        filter_params = query_params.urlencode()
        
        # Статистика
        total = attendances.count()
        present_percentage = absent_percentage = present_count = absent_count = 0
        
        if total > 0:
            present_status = Att_Status.objects.filter(name__icontains='присут').first()
            if present_status:
                present_count = attendances.filter(status=present_status).count()
                present_percentage = round((present_count / total) * 100, 1)
                absent_percentage = round(100 - present_percentage, 1)
                absent_count = total - present_count
        
        context = {
            'lesson': lesson,
            'group': lesson.id_group,
            'title': f"Посещаемость: {lesson.id_subject}, {lesson.date}",
            'filter_form': filter_form,
            'attendances': page_obj,
            'page_obj': page_obj,
            'filter_params': filter_params,
            'attendances_count': total,
            'present_percentage': present_percentage,
            'absent_percentage': absent_percentage,
            'present_count': present_count,
            'absent_count': absent_count,
            'all_statuses': Att_Status.objects.all(),
        }
        
        return render(request, self.template_name, context)
    
    def post(self, request, *args, **kwargs):
        """Обработка POST запроса - изменение статуса через AJAX"""
        lesson_id = self.kwargs.get("lesson_id")
        lesson = get_object_or_404(Lesson, pk=lesson_id)
        
        try:
            # Проверяем, это AJAX запрос
            if request.headers.get('Content-Type') == 'application/json':
                data = json.loads(request.body)
                
                if data.get('action') == 'update_attendance':
                    attendance_id = data.get('attendance_id')
                    status_id = data.get('status_id')
                    
                    # Получаем объекты
                    attendance = Attendance.objects.get(
                        id=attendance_id,
                        id_lesson=lesson
                    )
                    status = Att_Status.objects.get(id=status_id)
                    
                    # Обновляем статус
                    attendance.status = status
                    attendance.created_by = request.user
                    attendance.save()
                    
                    return JsonResponse({
                        'success': True,
                        'message': 'Статус успешно обновлен',
                        'status_name': status.name,
                        'attendance_id': attendance_id
                    })
            
            return JsonResponse({
                'success': False,
                'error': 'Некорректный запрос'
            }, status=400)
            
        except Attendance.DoesNotExist:
            return JsonResponse({
                'success': False,
                'error': 'Запись о посещаемости не найдена'
            }, status=404)
        except Att_Status.DoesNotExist:
            return JsonResponse({
                'success': False,
                'error': 'Указанный статус не существует'
            }, status=404)
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            }, status=500)
    
    def _get_filtered_attendances(self, lesson, filter_form):
        """Вспомогательный метод для фильтрации посещений"""
        queryset = Attendance.objects.filter(id_lesson=lesson)
        
        if filter_form.is_valid():
            cd = filter_form.cleaned_data
            
            # Фильтр по статусу посещения
            if cd.get('status'):
                queryset = queryset.filter(status_id=cd['status'])
            
            # Фильтр по фамилии студента
            if cd.get('last_name'):
                queryset = queryset.filter(id_student__last_name__icontains=cd['last_name'])
        
        # Оптимизируем запросы и сортируем
        queryset = queryset.select_related(
            "id_student__user",
            "status"
        ).order_by("id_student__last_name", "id_student__first_name")
        
        return queryset


# ================== ПРЕДСТАВЛЕНИЯ СТУДЕНТА ==================

class ProfileView(LoginRequiredMixin, StudentRequiredMixin, TemplateView):
    template_name = "student/profile.html"
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        student = self.request.user.student
        context["student"] = student
        context["user"] = student.user 
        context["title"] = "Мой профиль"
        return context


# journal/views.py (обновите класс StudentAttendanceListView)
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView
from django.db.models import Count, Q
from .models import Attendance, Att_Status
from .forms import StudentAttendanceFilterForm
import json
from datetime import datetime

class StudentAttendanceListView(LoginRequiredMixin, ListView):
    """Список посещаемости студента с фильтрацией и статистикой"""
    model = Attendance
    template_name = 'student/my_attendance.html'
    context_object_name = 'attendances'
    paginate_by = 15
    
    def get_queryset(self):
        # Базовый QuerySet: все посещения текущего студента
        student = self.request.user.student
        queryset = Attendance.objects.filter(id_student=student)
        
        # Инициализируем форму фильтрации
        self.filter_form = StudentAttendanceFilterForm(
            self.request.GET, 
            student=student
        )
        
        if self.filter_form.is_valid():
            cd = self.filter_form.cleaned_data
            
            # Фильтр по дате начала
            if cd.get('date_start'):
                queryset = queryset.filter(id_lesson__date__gte=cd['date_start'])
            
            # Фильтр по дате окончания
            if cd.get('date_end'):
                queryset = queryset.filter(id_lesson__date__lte=cd['date_end'])
            
            # Фильтр по предмету
            if cd.get('subject'):
                queryset = queryset.filter(id_lesson__id_subject=cd['subject'])
        
        # Оптимизируем запросы и сортируем
        queryset = queryset.select_related(
            "id_lesson__id_subject",
            "id_lesson__id_teacher__user",
            "id_lesson__id_group",
            "status"
        ).order_by("-id_lesson__date")
        
        return queryset
    
    def get_context_data(self, **kwargs):
        """Добавляем форму фильтрации и статистику в контекст"""
        context = super().get_context_data(**kwargs)
        
        # Получаем студента для формы
        student = self.request.user.student
        
        # Передаем форму в шаблон
        context['filter_form'] = StudentAttendanceFilterForm(
            self.request.GET, 
            student=student
        )
        
        # Сохраняем параметры фильтрации для пагинации
        query_params = self.request.GET.copy()
        if 'page' in query_params:
            query_params.pop('page')
        context['filter_params'] = query_params.urlencode()
        
        # Получаем отфильтрованные данные для статистики
        filtered_attendances = self.get_queryset()
        total_count = filtered_attendances.count()
        
        # Статистика по статусам
        status_stats = filtered_attendances.values(
            'status__name'
        ).annotate(
            count=Count('id')
        ).order_by('-count')
        
        # Подготовка данных для диаграммы
        chart_labels = []
        chart_data = []
        chart_colors = []
        
        # Цвета для разных статусов
        status_colors = {
            'Присутствовал': '#28a745',  # зеленый
            'Присутствует': '#28a745',
            'Отсутствовал': '#dc3545',   # красный
            'Отсутствует': '#dc3545',
            'Болел': '#ffc107',          # желтый
            'Опоздал': '#17a2b8',        # голубой
            'Уважительная': '#6c757d',   # серый
        }
        
        present_count = 0
        absent_count = 0
        
        for stat in status_stats:
            status_name = stat['status__name']
            count = stat['count']
            
            chart_labels.append(status_name)
            chart_data.append(count)
            
            # Определяем цвет
            color = status_colors.get(status_name, '#6c757d')
            chart_colors.append(color)
            
            # Считаем присутствия/отсутствия
            if 'присут' in status_name.lower():
                present_count += count
            elif 'отсут' in status_name.lower():
                absent_count += count
        
        # Если нет данных о статусах, считаем все как присутствие
        if total_count > 0 and present_count == 0 and absent_count == 0:
            present_count = total_count
        
        # Процент посещаемости
        present_percentage = 0
        absent_percentage = 0
        
        if total_count > 0:
            present_percentage = round((present_count / total_count) * 100, 1)
            absent_percentage = round(100 - present_percentage, 1)
        
        # Добавляем статистику в контекст
        context.update({
            'title': 'Моя посещаемость',
            'total_count': total_count,
            'present_count': present_count,
            'absent_count': absent_count,
            'present_percentage': present_percentage,
            'absent_percentage': absent_percentage,
            'chart_labels': json.dumps(chart_labels, ensure_ascii=False),
            'chart_data': json.dumps(chart_data),
            'chart_colors': json.dumps(chart_colors),
            'status_stats': status_stats,
        })
        
        # Добавляем параметры для скачивания
        context['download_params'] = query_params.urlencode()
        
        return context


@login_required
def export_group_students_excel(request, group_id):
    group = get_object_or_404(Group, id_group=group_id)
    
    if not (request.user.is_staff or 
            (hasattr(request.user, 'teacher') and request.user.teacher is not None)):
        return HttpResponseForbidden("У вас нет прав для экспорта данных")
    
    return export_students_to_excel(group)

import requests

def api_women_list(request):
    """
    View для отображения данных из API
    """
    api_url = 'http://127.0.0.1:8000/api/v1/women/'
    women_data = []
    error_message = None
    
    try:
        response = requests.get(api_url, timeout=5)
        if response.status_code == 200:
            women_data = response.json()
        else:
            error_message = f'Ошибка API: статус {response.status_code}'
    except requests.exceptions.ConnectionError:
        error_message = 'Ошибка подключения к API. Убедитесь, что API сервер запущен на порту 8000.'
    except Exception as e:
        error_message = f'Ошибка: {str(e)}'
    
    return render(request, 'api_women_list.html', {
        'women': women_data, 
        'error': error_message
    })