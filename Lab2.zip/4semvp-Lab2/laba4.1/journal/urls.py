# journal/urls.py
from django.urls import path
from django.contrib.auth import views as auth_views
from . import views 

urlpatterns = [
    path('', views.home, name="home"),
    path("login/", auth_views.LoginView.as_view(template_name='login.html'), name="login"),
    path("logout/", views.custom_logout, name="logout"),
    
    # Маршруты для преподавателя (teacher/*)
    path("teacher/groups/", views.GroupListView.as_view(), name="teacher-groups"),
    path("teacher/group/<int:group_id>/students/", views.StudentListView.as_view(), name="teacher-group-students"),
    path("teacher/group/<int:group_id>/lessons/", views.GroupLessonListView.as_view(), name="teacher-group-lessons"),
    path("teacher/lessons/", views.TeacherLessonListView.as_view(), name="teacher-lessons-all"),
    path("teacher/lesson/<int:lesson_id>/attendance/", views.AttendanceListView.as_view(), name="teacher-lesson-attendance"),
    path('api-data/', views.api_women_list, name='api-data'),
    
    # Маршруты для студента (student/*)
    path("student/profile/", views.ProfileView.as_view(), name="student-profile"),
    path("student/attendance/", views.StudentAttendanceListView.as_view(), name="student-attendance"),
    path('export/group/<str:group_id>/students/excel/', views.export_group_students_excel, name='export_group_students_excel'),
]