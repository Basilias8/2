from django.contrib.auth.mixins import UserPassesTestMixin
class TeacherRequiredMixin(UserPassesTestMixin):
    """Миксин, допускающий только пользователей с профилем преподавателя."""
    def test_func(self):
        user = self.request.user
        if not user.is_authenticated:
            return False
        # Проверяем наличие связанного объекта Teacher у пользователя
        return hasattr(user, 'teacher') and user.teacher is not None
    def handle_no_permission(self):
        # Если условие test_func не прошло, можно либо вызвать 403, либо перенаправить.
        # Мы вызываем стандартную обработку (по умолчанию даст 403 Forbidden).
        return super().handle_no_permission()
class StudentRequiredMixin(UserPassesTestMixin):
    """Миксин, допускающий только пользователей с профилем студента."""
    def test_func(self):
        user = self.request.user
        if not user.is_authenticated:
            return False
        return hasattr(user, 'student') and user.student is not None
    def handle_no_permission(self):
        return super().handle_no_permission()