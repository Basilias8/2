from rest_framework import serializers
from .models import Women, Category

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name', 'slug']


class WomenSerializer(serializers.ModelSerializer):
    cat_name = serializers.CharField(source='cat.name', read_only=True)
    category = CategorySerializer(source='cat', read_only=True)
    
    class Meta:
        model = Women
        fields = ['id', 'title', 'slug', 'content', 'cat', 'cat_name', 'category', 
                  'time_create', 'time_update', 'is_published']
        read_only_fields = ['id', 'time_create', 'time_update']


class WomenDetailSerializer(serializers.ModelSerializer):
    """Сериализатор для детального просмотра"""
    category = CategorySerializer(source='cat', read_only=True)
    
    class Meta:
        model = Women
        fields = ['id', 'title', 'slug', 'content',  'category', 
                  'time_create', 'time_update', 'is_published']
        read_only_fields = ['id', 'time_create', 'time_update']