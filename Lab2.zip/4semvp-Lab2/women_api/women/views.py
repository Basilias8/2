from rest_framework import generics, status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import api_view
from django.shortcuts import get_object_or_404
from django.http import Http404
from .models import Women, Category
from .serializers import WomenSerializer, WomenDetailSerializer, CategorySerializer

# ============ CRUD для Women ============

class WomenListCreateAPIView(generics.ListCreateAPIView):
    """
    GET: Список всех женщин
    POST: Создание новой записи
    """
    queryset = Women.objects.all().select_related('cat')
    
    def get_serializer_class(self):
        if self.request.method == 'POST':
            return WomenSerializer
        return WomenSerializer


class WomenRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    """
    GET: Детальная информация о женщине
    PUT: Полное обновление
    PATCH: Частичное обновление
    DELETE: Удаление с обработкой ошибок
    """
    queryset = Women.objects.all().select_related('cat')
    serializer_class = WomenDetailSerializer
    lookup_field = 'slug'
    
    def delete(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            instance.delete()
            return Response(
                {'message': f'Женщина "{instance.title}" успешно удалена'},
                status=status.HTTP_200_OK
            )
        except Http404:
            return Response(
                {'error': f'Женщина с slug "{kwargs.get("slug")}" не найдена'},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {'error': f'Ошибка при удалении: {str(e)}'},
                status=status.HTTP_400_BAD_REQUEST
            )


# ============ CRUD для Category ============

class CategoryListCreateAPIView(generics.ListCreateAPIView):
    """
    GET: Список всех категорий
    POST: Создание новой категории
    """
    queryset = Category.objects.all()
    serializer_class = CategorySerializer


class CategoryRetrieveUpdateDestroyAPIView(generics.RetrieveUpdateDestroyAPIView):
    """
    GET: Детальная информация о категории
    PUT: Полное обновление
    PATCH: Частичное обновление
    DELETE: Удаление с обработкой ошибок
    """
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    lookup_field = 'slug'
    
    def delete(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            instance.delete()
            return Response(
                {'message': f'Категория "{instance.name}" успешно удалена'},
                status=status.HTTP_200_OK
            )
        except Http404:
            return Response(
                {'error': f'Категория с slug "{kwargs.get("slug")}" не найдена'},
                status=status.HTTP_404_NOT_FOUND
            )
        except Exception as e:
            return Response(
                {'error': f'Ошибка при удалении: {str(e)}'},
                status=status.HTTP_400_BAD_REQUEST
            )


# ============ APIView примеры ============

@api_view(['GET', 'POST'])
def women_api_view(request):
    """Пример использования @api_view декоратора"""
    if request.method == 'GET':
        women = Women.objects.filter(is_published=True)
        serializer = WomenSerializer(women, many=True)
        return Response(serializer.data)
    
    elif request.method == 'POST':
        serializer = WomenSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET', 'PUT', 'PATCH', 'DELETE'])
def women_detail_api_view(request, slug):
    """Пример детального API view с декоратором"""
    try:
        woman = Women.objects.get(slug=slug)
    except Women.DoesNotExist:
        return Response(
            {'error': f'Женщина с slug "{slug}" не найдена'}, 
            status=status.HTTP_404_NOT_FOUND
        )
    
    if request.method == 'GET':
        serializer = WomenDetailSerializer(woman)
        return Response(serializer.data)
    
    elif request.method in ['PUT', 'PATCH']:
        partial = request.method == 'PATCH'
        serializer = WomenSerializer(woman, data=request.data, partial=partial)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    elif request.method == 'DELETE':
        woman.delete()
        return Response(
            {'message': f'Женщина "{woman.title}" успешно удалена'},
            status=status.HTTP_200_OK
        )