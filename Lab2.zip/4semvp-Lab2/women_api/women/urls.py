from django.urls import path
from . import views

urlpatterns = [
    # GET (список) и POST (создание) - один эндпоинт
    path('women/', views.WomenListCreateAPIView.as_view(), name='women-list'),
    
    # GET (детально), PUT (обновление), PATCH (частичное обновление), DELETE (удаление)
    path('women/<slug:slug>/', views.WomenRetrieveUpdateDestroyAPIView.as_view(), name='women-detail'),
    
    # Аналогично для категорий
    path('categories/', views.CategoryListCreateAPIView.as_view(), name='category-list'),
    path('categories/<slug:slug>/', views.CategoryRetrieveUpdateDestroyAPIView.as_view(), name='category-detail'),
]