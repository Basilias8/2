from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.http import JsonResponse

def api_root(request):
    return JsonResponse({
        'message': 'Добро пожаловать в API известных женщин',
        'endpoints': {
            'women': '/api/v1/women/',
            'categories': '/api/v1/categories/',
            'admin': '/admin/',
        }
    })

urlpatterns = [
    path('', api_root, name='root'),  # Добавляем корневой маршрут
    path('admin/', admin.site.urls),
    path('api/v1/', include('women.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)    